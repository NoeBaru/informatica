public class Telecomando {
    private boolean acceso;
    private int canale;
    private int volume;
    private boolean muto;
    private final int VOLUME_MAX;
    private final int CANALE_MAX;
    private static int VOLUME_DEFAULT = 100;
    private static int CANALE_DEFAULT = 999;

    public Telecomando(int volumeMax, int canaleMax){
        if(volumeMax <= 1){
            this.VOLUME_MAX=VOLUME_DEFAULT;
        }else{
            this.VOLUME_MAX=volumeMax;
        }
        if(canaleMax <= 1){
            this.canale=CANALE_DEFAULT;
            this.CANALE_MAX=CANALE_DEFAULT;
        }else{
            this.CANALE_MAX=canaleMax;
        }
        this.volume=VOLUME_DEFAULT / 2;
        this.canale=1;
        acceso=false;
    }

    public void setOnOff(){
        if(acceso==true){
            acceso=false;
        }else{
            acceso=true;
        }

        //acceso = !acceso
    }
    public void alzaVolume() {
        if (acceso == true) {

                volume ++;
                if (volume > VOLUME_MAX) {
                    volume = VOLUME_MAX;
                }
            if (volume > 0) {
                muto = false; //alzando il volume si toglie il muto
            }
        }
    }
    public void abbasaVolume() {
        if (acceso == true) {
                volume --;
                if (volume <= 0) {
                    volume = 0;
                   // muto = true;
                }
        }
    }
    public void alzaCanale() {
        if (acceso == true) {
                canale ++;
            if(canale > CANALE_MAX){
                canale = 1;
            }
        }
    }
    public void abbasaCanale() {
        if (acceso == true) {
                canale --;
                if(canale <= 0){
                    canale = CANALE_MAX;
                }
        }
    }
    public void setCanale(int canale){
        if(canale <= CANALE_MAX && canale > 0) {
            this.canale = canale;
        }
    }
    public boolean isAcceso(){
            return acceso;
    }

    public int getVolume(){
            return volume;
    }

    public int getCanale(){
        return canale;
    }
    public boolean isMuto(){
        return muto;
    }
    public void muteOnOff(){
        if(acceso){
            muto = !muto;
        }
    }
    public String toString(){
        String s= "acceso = " + acceso + " canale =" + canale + " volume =" + volume + " muto =" + muto +
                " volumeMax =" + VOLUME_MAX + " canaleMax =" + CANALE_MAX + " volumeDefault =" + VOLUME_DEFAULT +
                " canaleDefault =" + CANALE_DEFAULT;
        return s;
    }

}