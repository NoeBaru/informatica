public class Test {
    public static void main(String[] args) {
        int volumeMax = 101;
        int canaleMax = 1000;
        Telecomando t = new Telecomando(volumeMax, canaleMax);
        System.out.println(t);
        System.out.println(t.getVolume());
        t.alzaVolume();
        System.out.println(t.getVolume());
        System.out.println(t.isAcceso());
        t.setOnOff();
        System.out.println(t.isAcceso());
        System.out.println(t.getVolume());
        t.alzaVolume();
        System.out.println(t.getVolume());
        t.abbasaVolume();
        System.out.println(t.getVolume());
        t.alzaCanale();
        System.out.println(t.getCanale());
        t.abbasaCanale();
        System.out.println(t.getCanale());
        t.setCanale(30);
        System.out.println(t.getCanale());
        System.out.println(t.toString());
    }

}
