public class Libro extends Articolo{
    private int numeroPagine;
    private String autori;

    public Libro(String titolo, double valore, int numeroPagine, String autori) {
        super(titolo, valore);
        this.numeroPagine = numeroPagine;
        this.autori = autori;
    }

    public int getNumeroPagine() {
        return numeroPagine;
    }

    public void setNumeroPagine(int numeroPagine) {
        this.numeroPagine = numeroPagine;
    }

    public String getAutori() {
        return autori;
    }

    public void setAutori(String autori) {
        this.autori = autori;
    }
}
