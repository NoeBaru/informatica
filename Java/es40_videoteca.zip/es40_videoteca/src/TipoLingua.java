public enum TipoLingua {
    ITA,
    GB,
    F,
    D,
    ES
}
