public class Test {
    public static void main(String[] args) {
        Mul m = new Mul(5, 7);
        System.out.println(m.getRisultato());
        Add a = new Add(6, 7);
        System.out.println(a.getRisultato());
    }
}
