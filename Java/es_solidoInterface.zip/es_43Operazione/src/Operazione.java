public interface Operazione {
    double getRisultato();
}
