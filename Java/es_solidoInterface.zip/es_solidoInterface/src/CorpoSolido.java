public interface CorpoSolido {
    double getPeso();
}
