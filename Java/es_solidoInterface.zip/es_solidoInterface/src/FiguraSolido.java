public interface FiguraSolido {
    double getSuperficie();//sottointeso public e abstract
    double getVolume();
}
