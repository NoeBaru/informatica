public class Veicolo {
    private int codice;
    private String targa;
    private String marca;
    private String modello;

    public Veicolo(){

    }
    public void setCodice(int codice){
        if(codice > 0){
            this.codice = codice;
        } else{
            this.codice = 1;
        }
    }
    public String getCodice(){
        return codice;
    }
    public void setTarga(String targa){

    }
    public String getTarga(){
        return targa;
    }
    public void setMarca(String marca){

    }

    public String getMarca(){
        return marca;
    }
    public void setModello(String modello){

    }
    public String getModello(){
        return modello;
    }
    public String toString(){
        String s = "";
        return s;
    }
}
