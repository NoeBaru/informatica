public class Autonoleggio {
    private String nome;
    private String indirizzo;
    private Responsabile responsabile;
    private Veicolo[] veicoli;
    public final int MAX_VEICOLI = 2000;

    public Autonoleggio(){

    }
    public Autonoleggio(String nome, String indirizzo, Responsabile responsabile, Veicolo[] veicoli){

    }
    public boolean aggiungiVeicolo(Veicolo veicolo) {

    }
    public Veicolo trovaVeicolo(String targa) {

    }
    public Veicolo[] trovaTuttiIVeicoli(){

    }
    public String toString(){
        String s = "";
        return s;
    }
}
