package aggregazione;

public class Test {
    public static void main(String[] args) {
        Canzone c1 = new Canzone("Crepe", "Irama",202);
        Album a = new Album("Crepe", c1);   //un album deve avere almeno una canzone

        Canzone c2 = new Canzone("Mediterranea", "Irama",180);
        a.addCanzone(c2);
        System.out.println(a);
    }
}
