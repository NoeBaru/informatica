package aggregazione;

import java.util.Vector;

public class Album {
    private String titolo;
    private Vector<Canzone> brani;

    /*
    public Album(String titolo) {  //se l'album non deve avere almeno una canzone c'è questo costruttore
        this.titolo = titolo;
        this.brani = new Vector<>();
    }
*/
    public Album(String titolo, Canzone canzone) {  //se l'album deve avere almeno una canzone
        this.titolo = titolo;
        this.brani = new Vector<>();
        addCanzone(canzone);
    }

    public void addCanzone(Canzone canzone) {
        if(canzone != null) {
            this.brani.add(canzone);
        }
        else throw new NullPointerException("Non hai aggiunto nulla");
    }

    @Override
    public String toString() {
        String s=  "'" + titolo + "':\n";
        for (Canzone c : brani) {
            s += "\t" + c.toString() + "\n";
        }
        return s;
    }
// Tanti metodi per gestire canzoni
    // Ricerca, rimuovi, leggi in una posizione, ecc
}

