package composizione;

import java.util.Vector;

public class Album {
    private String titolo;
    private Vector<Canzone> brani;

    /*
    //se un album NON deve contenere almeno una canzone c'è solo questo
    public Album(String titolo) { //
        this.titolo = titolo;
        this.brani = new Vector<>();
    }
     */

    //un album deve contenere almeno una canzone 
    public Album(String titolo, String titoloCanzone, String autore, int durataSec) { //
        this.titolo = titolo;
        this.brani = new Vector<>();
        addCanzone(titoloCanzone, autore, durataSec);
    }

    public void addCanzone(String titolo, String autore, int durataSecondi) {
        this.brani.add(new Canzone(titolo, autore, durataSecondi));
    }

    @Override
    public String toString() {
        String s=  "'" + titolo + "':\n";
        for (Canzone c : brani) {
            s += "\t" + c.toString() + "\n";
        }
        return s;
    }


    // Poi tanti metodi per aggiungere, rimuovere, cercare, ecc

    public class Canzone {
        private String titolo;
        private String autore;
        private int durataSec;

        public Canzone(String titolo, String autore, int durataSec) {
            this.titolo = titolo;
            this.autore = autore;
            this.durataSec = durataSec;
        }

        public String getTitolo() {
            return titolo;
        }

        public String getAutore() {
            return autore;
        }

        public int getDurataSec() {
            return durataSec;
        }

        @Override
        public String toString() {
            return "'" + titolo + '\'' +
                    " di " + autore + ",durata=" + durataSec ;
        }
    }
}
