package composizione;

public class Test {
    public static void main(String[] args) {
        //pre creare un album devo anche passare i valori per la prima canzone
        Album a = new Album("Crepe", "Crepe", "Irama",202);
        a.addCanzone("Mediterranea", "Irama",180);
        System.out.println(a);

        //se Canzone pubblica si può scrivere, ma non è aggiunta
        Album.Canzone c = a.new Canzone("ma","bho",3);
        System.out.println(c);
    }
}
